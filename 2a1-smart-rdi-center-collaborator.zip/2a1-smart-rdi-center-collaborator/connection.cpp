#include "connection.h"

Connection::Connection(){}

bool Connection::createconnection()
{
    db = QSqlDatabase::addDatabase("QODBC");
    bool test=false;
    db.setDatabaseName("source_project2a");// insert the name of data source ODBC
    db.setUserName("azer");//insert username
    db.setPassword("azer");//insert passeword


    if (db.open())  test = true ;

        return  test;
    return true;
}

void Connection::closeConnection(){ db.close(); }
