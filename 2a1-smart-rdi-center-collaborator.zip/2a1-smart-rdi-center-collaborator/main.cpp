#include "mainwindow.h"
#include <QApplication>
#include <QMessageBox>
#include "connection.h"

//#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    Arduino A;
    Connection c;
    bool test=c.createconnection();
        MainWindow w;
    if(test)
    {w.show();

      /*QMessageBox::critical(nullptr, QObject::tr("database is open"),
                    QObject::tr("connection successful.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);*/

}
    else
        QMessageBox::critical(nullptr, QObject::tr("database is not open"),
                    QObject::tr("connection failed.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);


    QString value = A.read_from_arduino2(); // assuming A is an instance of your Arduino object
 //ui->arduinoo->setText(value);
    if (value.length() > 4) {
        // Execute the query to check if the value is present in the database
        QSqlQuery query;
        query.prepare("SELECT LAST_NAME FROM collaborator WHERE FIRST_NAME = :FIRST_NAME");
        query.bindValue(":FIRST_NAME", value);
        if (query.exec() && query.next()) {
            // If the value is found, send the name of the person to the Arduino
            QString name = query.value(0).toString();
            QByteArray data = name.toUtf8();
            A.write_to_arduino(data);
        } else {
            // If the value is not found, send "not found" to the Arduino
            QByteArray data = "not found";
            A.write_to_arduino(data);
        }
    }

    return a.exec();
}
