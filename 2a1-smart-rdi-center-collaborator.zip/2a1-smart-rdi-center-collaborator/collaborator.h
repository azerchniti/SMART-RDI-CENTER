#ifndef STUDENT_H
#define STUDENT_H
#include<QString>
#include<QSqlQuery>
#include<QSqlQueryModel>
#include<QString>

class collaborator
{
    int ID_COLLAB;
    QString FIRST_NAME, LAST_NAME, EMAIL, INSTITUTION, ADDRESS, STATUS;
    int PHONE_NUMBER;

public:
    // Constructors
    collaborator() {}
    collaborator(int id, QString firstName, QString lastName, QString email, QString institution,
                 QString address, QString status, int phoneNumber);

    // Getters
    int getID_COLLAB() { return ID_COLLAB; }
    QString getFIRST_NAME() { return FIRST_NAME; }
    QString getLAST_NAME() { return LAST_NAME; }
    QString getEMAIL() { return EMAIL; }
    QString getINSTITUTION() { return INSTITUTION; }
    QString getADDRESS() { return ADDRESS; }
    QString getSTATUS() { return STATUS; }
    int getPHONE_NUMBER() { return PHONE_NUMBER; }

    // Setters
    void setID_COLLAB(int id) { ID_COLLAB = id; }
    void setFIRST_NAME(QString firstName) { FIRST_NAME = firstName; }
    void setLAST_NAME(QString lastName) { LAST_NAME = lastName; }
    void setEMAIL(QString email) { EMAIL = email; }
    void setINSTITUTION(QString institution) { INSTITUTION = institution; }
    void setADDRESS(QString address) { ADDRESS = address; }
    void setSTATUS(QString status) { STATUS = status; }
    void setPHONE_NUMBER(int phoneNumber) { PHONE_NUMBER = phoneNumber; }

    // Other functions
    bool Create();
    QSqlQueryModel *Read();
    QSqlQueryModel *Readsorted();
    QSqlQueryModel *    Readsorted_Fname();
    QSqlQueryModel *    Readsorted_Lname();
    QSqlQueryModel *    Readsorted_Status();
    QSqlQueryModel *    Readsorted_Address();
    QSqlQueryModel *    Readsorted_ID();


    QSqlQueryModel *search(QString);
      bool  ExportPDF(QString);
    bool Delete(int);
    bool update();
};


#endif // Student_H

