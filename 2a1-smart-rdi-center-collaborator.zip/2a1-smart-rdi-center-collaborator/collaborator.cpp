#include "collaborator.h"
#include <QPdfWriter>
#include <QPainter>
#include <QTableView>
#include <QFileDialog>
#include <QFileDialog>
#include <QMessageBox>
#include <QSqlQueryModel>
#include <QStandardItem>
#include <QModelIndex>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QSqlTableModel>
#include <QSqlRecord>
#include <QSqlField>
#include <QMessageBox>
#include <QTableView>
#include <QPushButton>
#include <QVBoxLayout>
#include <QStyledItemDelegate>
#include <Qt>
#include <QObject>




collaborator::collaborator(int id, QString firstName, QString lastName, QString email, QString institution,
                           QString address, QString status, int phoneNumber)
{
    this->ID_COLLAB = id;
    this->FIRST_NAME = firstName;
    this->LAST_NAME = lastName;
    this->EMAIL = email;
    this->INSTITUTION = institution;
    this->ADDRESS = address;
    this->STATUS = status;
    this->PHONE_NUMBER = phoneNumber;
}


bool collaborator::Create()
{
    QSqlQuery query;

    QString id_str = QString::number(ID_COLLAB);
    QString phone_str = QString::number(PHONE_NUMBER);

    // Prepare the query
    query.prepare("INSERT INTO Collaborator (ID_COLLAB, FIRST_NAME, LAST_NAME, EMAIL, INSTITUTION, ADDRESS, STATUS, PHONE_NUMBER) "
                  "VALUES (:id, :firstName, :lastName, :email, :institution, :address, :status, :phoneNumber)");

    // Bind values to the query parameters
    query.bindValue(":id", id_str);
    query.bindValue(":firstName", FIRST_NAME);
    query.bindValue(":lastName", LAST_NAME);
    query.bindValue(":email", EMAIL);
    query.bindValue(":institution", INSTITUTION);
    query.bindValue(":address", ADDRESS);
    query.bindValue(":status", STATUS);
    query.bindValue(":phoneNumber", phone_str);

    // Execute the query and return the result
    return query.exec();
}


QSqlQueryModel * collaborator::Read()
{
    QSqlQueryModel* model = new QSqlQueryModel();
    model->setQuery("SELECT ID_COLLAB, FIRST_NAME, LAST_NAME, EMAIL, INSTITUTION, ADDRESS, STATUS, PHONE_NUMBER FROM Collaborator");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID_COLLAB"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("FIRST_NAME"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("LAST_NAME"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("EMAIL"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("INSTITUTION"));
    model->setHeaderData(5, Qt::Horizontal, QObject::tr("ADDRESS"));
    model->setHeaderData(6, Qt::Horizontal, QObject::tr("STATUS"));
    model->setHeaderData(7, Qt::Horizontal, QObject::tr("PHONE_NUMBER"));


    return model;
}
//by institution
QSqlQueryModel * collaborator::Readsorted()
{
    QSqlQueryModel* model = new QSqlQueryModel();
    model->setQuery("SELECT ID_COLLAB, FIRST_NAME, LAST_NAME, EMAIL, INSTITUTION, ADDRESS, STATUS, PHONE_NUMBER FROM Collaborator ORDER BY INSTITUTION ");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID_COLLAB"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("FIRST_NAME"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("LAST_NAME"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("EMAIL"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("INSTITUTION"));
    model->setHeaderData(5, Qt::Horizontal, QObject::tr("ADDRESS"));
    model->setHeaderData(6, Qt::Horizontal, QObject::tr("STATUS"));
    model->setHeaderData(7, Qt::Horizontal, QObject::tr("PHONE_NUMBER"));
    return model;
}



QSqlQueryModel * collaborator::Readsorted_Fname()
{
    QSqlQueryModel* model = new QSqlQueryModel();
    model->setQuery("SELECT ID_COLLAB, FIRST_NAME, LAST_NAME, EMAIL, INSTITUTION, ADDRESS, STATUS, PHONE_NUMBER FROM Collaborator ORDER BY FIRST_NAME ");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID_COLLAB"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("FIRST_NAME"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("LAST_NAME"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("EMAIL"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("INSTITUTION"));
    model->setHeaderData(5, Qt::Horizontal, QObject::tr("ADDRESS"));
    model->setHeaderData(6, Qt::Horizontal, QObject::tr("STATUS"));
    model->setHeaderData(7, Qt::Horizontal, QObject::tr("PHONE_NUMBER"));
    return model;
}

QSqlQueryModel * collaborator::Readsorted_Lname()
{
    QSqlQueryModel* model = new QSqlQueryModel();
    model->setQuery("SELECT ID_COLLAB, FIRST_NAME, LAST_NAME, EMAIL, INSTITUTION, ADDRESS, STATUS, PHONE_NUMBER FROM Collaborator ORDER BY LAST_NAME ");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID_COLLAB"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("FIRST_NAME"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("LAST_NAME"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("EMAIL"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("INSTITUTION"));
    model->setHeaderData(5, Qt::Horizontal, QObject::tr("ADDRESS"));
    model->setHeaderData(6, Qt::Horizontal, QObject::tr("STATUS"));
    model->setHeaderData(7, Qt::Horizontal, QObject::tr("PHONE_NUMBER"));
    return model;
}

QSqlQueryModel * collaborator::Readsorted_ID()
{
    QSqlQueryModel* model = new QSqlQueryModel();
    model->setQuery("SELECT ID_COLLAB, FIRST_NAME, LAST_NAME, EMAIL, INSTITUTION, ADDRESS, STATUS, PHONE_NUMBER FROM Collaborator ORDER BY ID_COLLAB ");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID_COLLAB"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("FIRST_NAME"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("LAST_NAME"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("EMAIL"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("INSTITUTION"));
    model->setHeaderData(5, Qt::Horizontal, QObject::tr("ADDRESS"));
    model->setHeaderData(6, Qt::Horizontal, QObject::tr("STATUS"));
    model->setHeaderData(7, Qt::Horizontal, QObject::tr("PHONE_NUMBER"));
    return model;
}
QSqlQueryModel * collaborator::Readsorted_Status()
{
    QSqlQueryModel* model = new QSqlQueryModel();
    model->setQuery("SELECT ID_COLLAB, FIRST_NAME, LAST_NAME, EMAIL, INSTITUTION, ADDRESS, STATUS, PHONE_NUMBER FROM Collaborator ORDER BY STATUS ");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID_COLLAB"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("FIRST_NAME"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("LAST_NAME"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("EMAIL"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("INSTITUTION"));
    model->setHeaderData(5, Qt::Horizontal, QObject::tr("ADDRESS"));
    model->setHeaderData(6, Qt::Horizontal, QObject::tr("STATUS"));
    model->setHeaderData(7, Qt::Horizontal, QObject::tr("PHONE_NUMBER"));
    return model;
}

QSqlQueryModel * collaborator::Readsorted_Address()
{
    QSqlQueryModel* model = new QSqlQueryModel();
    model->setQuery("SELECT ID_COLLAB, FIRST_NAME, LAST_NAME, EMAIL, INSTITUTION, ADDRESS, STATUS, PHONE_NUMBER FROM Collaborator ORDER BY ADDRESS ");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID_COLLAB"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("FIRST_NAME"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("LAST_NAME"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("EMAIL"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("INSTITUTION"));
    model->setHeaderData(5, Qt::Horizontal, QObject::tr("ADDRESS"));
    model->setHeaderData(6, Qt::Horizontal, QObject::tr("STATUS"));
    model->setHeaderData(7, Qt::Horizontal, QObject::tr("PHONE_NUMBER"));
    return model;
}

QSqlQueryModel * collaborator::search(QString x)
{   ;
    QSqlQueryModel* model = new QSqlQueryModel();
    model->setQuery("SELECT ID_COLLAB, FIRST_NAME, LAST_NAME, EMAIL, INSTITUTION, ADDRESS, STATUS, PHONE_NUMBER FROM Collaborator WHERE FIRST_NAME = '" + x + "'");


    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID_COLLAB"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("FIRST_NAME"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("LAST_NAME"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("EMAIL"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("INSTITUTION"));
    model->setHeaderData(5, Qt::Horizontal, QObject::tr("ADDRESS"));
    model->setHeaderData(6, Qt::Horizontal, QObject::tr("STATUS"));
    model->setHeaderData(7, Qt::Horizontal, QObject::tr("PHONE_NUMBER"));
    return model;
}



bool collaborator::Delete(int id)
{
    QSqlQuery query;
    QString res = QString::number(id);

    query.prepare("DELETE FROM Collaborator WHERE ID_COLLAB = :id");
    query.bindValue(":id", res);

    return query.exec();
}


bool collaborator::update()
{
    QSqlQuery query;

    QString id_str = QString::number(ID_COLLAB);
    QString phone_str = QString::number(PHONE_NUMBER);

    // Prepare the query
    query.prepare("UPDATE Collaborator SET FIRST_NAME = :firstName, LAST_NAME = :lastName, EMAIL = :email, INSTITUTION = :institution, ADDRESS = :address, STATUS = :status, PHONE_NUMBER = :phoneNumber WHERE ID_COLLAB = :id");


    // Bind values to the query parameters
    query.bindValue(":id", id_str);
    query.bindValue(":firstName", FIRST_NAME);
    query.bindValue(":lastName", LAST_NAME);
    query.bindValue(":email", EMAIL);
    query.bindValue(":institution", INSTITUTION);
    query.bindValue(":address", ADDRESS);
    query.bindValue(":status", STATUS);
    query.bindValue(":phoneNumber", phone_str);

    // Execute the query and return the result
    return query.exec();
}





/*

bool Student::Create()
{
    //TODO
}

QSqlQueryModel * Student::Read()
{
    //TODO
}

bool Student::Delete(int id)
{
    //TODO
}
 */
