#ifndef WEBAXWIDGET_H
#define WEBAXWIDGET_H

#include <ActiveQt/QAxWidget>
#include "windows.h"

// Define a custom QWidget subclass that inherits from QAxWidget
class WebAxWidget : public QAxWidget
{
public:
    // Define a constructor that calls the QAxWidget constructor with the parent and flags arguments
    WebAxWidget(QWidget *parent = nullptr, Qt::WindowFlags f = 0)
        : QAxWidget(parent, f)
    {
    }

protected:
    // Override the translateKeyEvent() method to handle keyboard events
    bool translateKeyEvent(int message, int keycode) const Q_DECL_OVERRIDE
    {
        // If the message is a key event message, return true to indicate that the event has been handled
        if (message >= WM_KEYFIRST && message <= WM_KEYLAST)
            return true;

        // If the message is not a key event message, call the base class method to handle the event
        return QAxWidget::translateKeyEvent(message, keycode);
    }
};


#endif // WEBAXWIDGET_H
