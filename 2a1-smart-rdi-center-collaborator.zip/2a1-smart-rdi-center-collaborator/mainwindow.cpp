#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "collaborator.h"
#include <QMainWindow>
#include <QMessageBox>
#include<QThread>
#include <QIntValidator>
#include <QMessageBox>
#include <QTextStream>
#include <QFileDialog>
#include <QTextDocument>
#include <QPdfWriter>
#include <QPainter>
#include <QTableView>
#include <QFileDialog>
#include <QPrinter>
#include <QPrintDialog>
#include <QtCharts>
#include "widget.h"
#include "arduino.h"
#include <QTimer>


using namespace DuarteCorporation;



MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{


    ui->setupUi(this);
    ui->tableView->setModel(Etmp.Read());

    //maps
    QSettings settings(QSettings::IniFormat, QSettings::UserScope,
                       QCoreApplication::organizationName(), QCoreApplication::applicationName());

   // ui->WebNav->dynamicCall("Navigate(const QString&)", "https://www.google.com/maps/place/ESPRIT/@36.9016729,10.1713215,15z");
    ui->WebNav->dynamicCall("Navigate(const QString&)", "https://www.google.com/maps/place/ESPRIT");

    //arduino
    int ret=A.connect_arduino(); // launch the connection to arduino
    switch(ret){
    case(0):qDebug()<< "arduino is available and connected to : "<< A.getarduino_port_name();
        break;
    case(1):qDebug() << "arduino is available but not connected to :" <<A.getarduino_port_name();
       break;
    case(-1):qDebug() << "arduino is not available";
    }
     QObject::connect(A.getserial(),SIGNAL(readyRead()),this,SLOT(update_label())); //allows to
     //launch the update_label slot following the reception of the readyRead signal (reception of data).
     QTimer *timer = new QTimer(this);
       connect(timer, SIGNAL(timeout()), this, SLOT(runLoop()));
       timer->start(1000);

}




MainWindow::~MainWindow()
{

    delete ui;

}

//add
void MainWindow::on_add_3_clicked()
{

    // Get information entered in the 3 fields
    int ID_COLLAB = ui->collaborator_id->text().toInt();
    QString LAST_NAME = ui->collaborator_LastName->text();
    QString FIRST_NAME = ui->collaborator_FirstName->text();
    QString EMAIL = ui->collaborator_Email->text();
    QString INSTITUTION = ui->collaborator_Institution->text();
    QString ADDRESS = ui->collaborator_Address->text();
    QString STATUS;

    if (ui->active->isChecked()) {
        STATUS = "Active";
    } else if (ui->pending->isChecked()) {
        STATUS = "pending";
    }

    QString PHONE_NUMBER_STRING = ui->collaborator_PhoneNumber->text();

    // Check if first name and last name do not contain special characters or numbers
    QRegularExpression regex("^[a-zA-Z\\s]*$"); // Regex for alphabetical characters and spaces
    if (!regex.match(FIRST_NAME).hasMatch() || !regex.match(LAST_NAME).hasMatch()) {
        QMessageBox::warning(nullptr, QObject::tr("Invalid input"),
                QObject::tr("First and last name should only contain alphabetical characters and spaces."),
                QMessageBox::Ok);
        return;
    }

    // Check if email contains @ and .
    if (!EMAIL.contains("@") || !EMAIL.contains(".")) {
        QMessageBox::warning(nullptr, QObject::tr("Invalid input"),
                QObject::tr("Invalid email address. email should contain @ and .  "),
                QMessageBox::Ok);
        return;
    }

    // Check if phone number contains only 8 numbers
    QRegularExpression regex_phone("^\\d{8}$"); // Regex for 8 digits
    if (!regex_phone.match(PHONE_NUMBER_STRING).hasMatch()) {
        QMessageBox::warning(nullptr, QObject::tr("Invalid input"),
                QObject::tr("Phone number should contain exactly 8 digits."),
                QMessageBox::Ok);
        return;
    }

    int PHONE_NUMBER = PHONE_NUMBER_STRING.toInt();

    collaborator newCollaborator(ID_COLLAB, FIRST_NAME, LAST_NAME, EMAIL, INSTITUTION, ADDRESS, STATUS, PHONE_NUMBER);

    // object instantiation using information entered in the interface
    bool test = newCollaborator.Create(); // insert the object into the database Student table and get the returned value of query.exec()

    if (test) { // if the query is executed  ==> QMessageBox::information
        // Refresh
        ui->tableView->setModel(Etmp.Read());
        QMessageBox::information(nullptr, QObject::tr("OK"),
                QObject::tr("Insert done.\nClick Cancel to exit."), QMessageBox::Cancel);
    } else { // if the query is not executed  ==> QMessageBox::critical
        QMessageBox::critical(nullptr, QObject::tr("Not OK"),
                QObject::tr("Insert failed.\nClick Cancel to exit."), QMessageBox::Cancel);
    }

    ui->collaborator_id->clear();
    ui->collaborator_LastName->clear();
    ui->collaborator_FirstName->clear();
    ui->collaborator_Email->clear();
    ui->collaborator_Institution->clear();
    ui->collaborator_Address->clear();
    ui->id_delete->clear();
    ui->collaborator_PhoneNumber->clear();


 }

//delete button
void MainWindow::on_add_2_clicked()
{
    int id =ui->id_delete->text().toInt();
    bool test=Etmp.Delete(id);

    if(test)
    {
        // Refresh (Actualiser)
        ui->tableView->setModel(Etmp.Read());

        QMessageBox::information(nullptr, QObject::tr("OK"),
                    QObject::tr("delete done\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
    {QMessageBox::critical(nullptr, QObject::tr("Not OK"),
                    QObject::tr("delete failed.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);}
    ui->collaborator_id->clear();
    ui->collaborator_LastName->clear();
    ui->collaborator_FirstName->clear();
    ui->collaborator_Email->clear();
    ui->collaborator_Institution->clear();
     ui->collaborator_Address->clear();
     ui->id_delete->clear();
     ui->collaborator_PhoneNumber->clear();

}


void MainWindow::on_update_clicked()
{
    // Get information entered in the 3 fields
    int ID_COLLAB = ui->collaborator_id->text().toInt();
    QString LAST_NAME = ui->collaborator_LastName->text();
    QString FIRST_NAME = ui->collaborator_FirstName->text();
    QString EMAIL = ui->collaborator_Email->text();
    QString INSTITUTION = ui->collaborator_Institution->text();
    QString ADDRESS = ui->collaborator_Address->text();
    QString STATUS;
       if (ui->active->isChecked()) {
           STATUS = "Active";
       } else if (ui->pending->isChecked()) {
           STATUS = "pending";
       }

    int PHONE_NUMBER = ui->collaborator_PhoneNumber->text().toInt();

    collaborator newCollaborator(ID_COLLAB, FIRST_NAME, LAST_NAME, EMAIL, INSTITUTION, ADDRESS, STATUS, PHONE_NUMBER);
    // object instantiation
                              // using information entered in the interface

    bool test= newCollaborator.update(); // insert the object into the databse Student table
                          // and et the returned value of query.exec()

    if(test) // if the query is executed  ==> QMessageBox::information
    {
        // Refresh²²
        ui->tableView->setModel(Etmp.Read());

        QMessageBox::information(nullptr, QObject::tr("OK"),
                    QObject::tr("modification is done \n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else // if the query is not executed  ==> QMessageBox::critical
      {  QMessageBox::critical(nullptr, QObject::tr("Not OK"),
                    QObject::tr("modification is failed.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);}
    ui->collaborator_id->clear();
    ui->collaborator_LastName->clear();
    ui->collaborator_FirstName->clear();
    ui->collaborator_Email->clear();
    ui->collaborator_Institution->clear();
     ui->collaborator_Address->clear();
     ui->id_delete->clear();
     ui->collaborator_PhoneNumber->clear();

}

//sort
void MainWindow::on_sort_clicked()
{

    QString SORT_TYPE = ui->sorttype->currentText();
    if (SORT_TYPE=="Institution")
   { ui->tableView->setModel(Etmp.Readsorted());}
    else if  (SORT_TYPE=="First_Name")
    { ui->tableView->setModel(Etmp.Readsorted_Fname());}
    else if  (SORT_TYPE=="Last_Name")
    { ui->tableView->setModel(Etmp.Readsorted_Lname());}
    else if  (SORT_TYPE=="Status")
    { ui->tableView->setModel(Etmp.Readsorted_Status());}
    else if  (SORT_TYPE=="Address")
    { ui->tableView->setModel(Etmp.Readsorted_Address());}
    else if  (SORT_TYPE=="ID")
    { ui->tableView->setModel(Etmp.Readsorted_ID());}
}



//print screenshot
void MainWindow::on_Print_clicked()
{

    QString filename = QFileDialog::getSaveFileName(this, "Save PDF", "", "*.pdf");
        if (!filename.isEmpty())
        {
            QPrinter printer(QPrinter::PrinterResolution);
            printer.setOutputFormat(QPrinter::PdfFormat);
            printer.setPaperSize(QPrinter::A1);
            printer.setOutputFileName(filename);

            QPainter painter(&printer);

            ui->tableView->render(&painter);
            painter.end();

            QMessageBox::information(this, "Export Successful", "The table has been exported to PDF successfully!");
        }
        else
        {
            QMessageBox::critical(this, "Export Failed", "Failed to export the table to PDF!");
        }

}

void MainWindow::on_tableView_clicked(const QModelIndex &index)
{
    // Get data from the model for the selected row
       QString id = index.sibling(index.row(), 0).data().toString();
       QString firstName = index.sibling(index.row(), 1).data().toString();
       QString lastName = index.sibling(index.row(), 2).data().toString();
       QString email = index.sibling(index.row(), 3).data().toString();
       QString institution = index.sibling(index.row(), 4).data().toString();
       QString address = index.sibling(index.row(), 5).data().toString();
       QString status = index.sibling(index.row(), 6).data().toString();
       QString phoneNumber = index.sibling(index.row(), 7).data().toString();

       // Set the data into the corresponding line edits
       ui->collaborator_id->setText(id);
       ui->collaborator_FirstName->setText(firstName);
       ui->collaborator_LastName->setText(lastName);
       ui->collaborator_Email->setText(email);
       ui->collaborator_Institution->setText(institution);
       ui->collaborator_Address->setText(address);
       if (status == "Active") {
           ui->active->setChecked(true);
       } else if (status == "pending") {
           ui->pending->setChecked(true);
       }
       ui->collaborator_PhoneNumber->setText(phoneNumber);

       ui->id_delete->setText(id);
       address="https://www.google.com/maps/place/" + address;
       ui->WebNav->dynamicCall("Navigate(const QString&)", address);

}

void MainWindow::on_pushButton_clicked()//pdf
{
    //QString filename = "C:/Users/asus/OneDrive - ESPRIT/Bureau/test11.pdf";

    // Open a file dialog box and allow the user to choose a filename and location for the PDF file
    QString filename = QFileDialog::getSaveFileName(this, "Save PDF", "", "*.pdf");

    // Check if the user has chosen a filename
    if (!filename.isEmpty())
    {
        // Create a QPrinter object for printing to PDF
        QPrinter printer(QPrinter::PrinterResolution);

        // Set the output format of the QPrinter to PDF
        printer.setOutputFormat(QPrinter::PdfFormat);

        // Set the filename of the PDF file to be created
        printer.setOutputFileName(filename);

        // Create a QPainter object for painting on the QPrinter
        QPainter painter(&printer);

        // Create an empty string to store the text that will be written to the PDF
        QString text = "";

        // Execute a SQL query to select all rows from the Collaborator table
        QSqlQuery query;
        query.exec("SELECT * FROM Collaborator");

        // Loop through the rows returned by the query and append the data to the text string
        while (query.next())
        {
            text += "ID_COLLAB: " + query.value(0).toString() + "\n";
            text += "First_Name: " + query.value(1).toString() + "\n";
            text += "Last_Name: " + query.value(2).toString() + "\n";
            text += "Email: " + query.value(3).toString() + "\n";
            text += "Institution: " + query.value(4).toString() + "\n";
            text += "Address: " + query.value(5).toString() + "\n";
            text += "Phone_Number: " + query.value(6).toString() + "\n "+ "\n "+ "\n "+ "\n ";
        }

        // Use the QPainter object to write the text to the PDF
        painter.drawText(QRect(100, 100, 1000, 1000), text);

        // End the painting on the QPrinter object
        painter.end();

        // Display a success message box to the user
        QMessageBox::information(this, "Export Successful", "The table has been exported to PDF successfully!");
    }
    else
    {
        // Display an error message box to the user if the filename is empty
        QMessageBox::critical(this, "Export Failed", "Failed to export the table to PDF!");
    }

}
//statistics with no chart
void MainWindow::on_pushButton_2_clicked()
{
    // Query the database to get the number of active and pending collaborators
       QSqlQuery query;
       query.prepare("SELECT COUNT(*) FROM Collaborator WHERE STATUS = 'Active'");
       query.exec();
       query.next();
       int activeCount = query.value(0).toInt();

       query.prepare("SELECT COUNT(*) FROM Collaborator WHERE STATUS = 'pending'");
       query.exec();
       query.next();
       int pendingCount = query.value(0).toInt();

       // Calculate the percentage of active and pending collaborators
       int totalCount = activeCount + pendingCount;
       double activePercentage = static_cast<double>(activeCount) / totalCount * 100;
       double pendingPercentage = static_cast<double>(pendingCount) / totalCount * 100;

       // Display the result to the user
       QString result = QString("Active: %1%  Pending: %2%").arg(activePercentage).arg(pendingPercentage);
       QMessageBox::information(this, "Collaborator Status", result);

}
//statistics
void MainWindow::on_pushButton_3_clicked()
{
   //stat

        // Query the database to get the number of active and pending collaborators
        QSqlQuery query;
        query.prepare("SELECT COUNT(*) FROM Collaborator WHERE status = 'Active'");
        query.exec();
        query.next();
        int activeCount = query.value(0).toInt();

        query.prepare("SELECT COUNT(*) FROM Collaborator WHERE status = 'pending'");
        query.exec();
        query.next();
        int pendingCount = query.value(0).toInt();

        // Create a pie series and add the data to it
        QPieSeries *series = new QPieSeries();
        series->append("Active", activeCount);
        series->append("Pending", pendingCount);

        // Create a chart and add the series to it
        QChart *chart = new QChart();
        chart->addSeries(series);
        chart->setTitle("Collaborator Status");

        // Create a chart view and set the chart as its model
        QChartView *chartView = new QChartView(chart);
        chartView->setRenderHint(QPainter::Antialiasing);

        // Create a dialog to display the chart view
        QDialog *dialog = new QDialog(this);
        dialog->setWindowTitle("Collaborator Status");
        dialog->resize(400, 300);
        QVBoxLayout *layout = new QVBoxLayout(dialog);
        layout->addWidget(chartView);

        // Show the dialog
        dialog->exec();

}

//chat
void MainWindow::on_sort_2_clicked()
{
    widget w;
    w.exec();
}
//full screen
void MainWindow::on_pushButton_4_clicked()
{
     showFullScreen();
}
//minimize
void MainWindow::on_pushButton_5_clicked()
{
    showNormal();

}
//search
void MainWindow::on_searchcollab_textChanged(const QString &arg1)
{
    QString First_NAME = ui->searchcollab->text();

    ui->tableView->setModel(Etmp.search(First_NAME));
}
//arduino
void MainWindow::on_pushButton_6_clicked()
{
        //QString bro = ui->brooo->text();
       // QByteArray data = bro.toUtf8();

       // A.write_to_arduino(data);
    QString value = A.read_from_arduino2(); // assuming A is an instance of your Arduino object
    ui->arduinoo->setText(value);

        // Execute the query to check if the value is present in the database
        QSqlQuery query;
        query.prepare("SELECT FIRST_NAME FROM collaborator WHERE Institution = :Institution");
        query.bindValue(":Institution", value);
        if (query.exec() && query.next()) {
            // If the value is found, send the name of the person to the Arduino
            QString name = query.value(0).toString();
            QByteArray data = name.toUtf8();
            A.write_to_arduino(data);
        } else {
            // If the value is not found, send "not found" to the Arduino
            QByteArray data = "not found";
            A.write_to_arduino(data);
        }



}
//int value = ui->box->value();
// QByteArray data = QByteArray::number(value);



void MainWindow::on_pushButton_7_clicked()
{
    // Get the value of the spin box
       int value = ui->SPIN->value();

       // Execute the query to check if the value is present in the database
       QSqlQuery query;
       query.prepare("SELECT FIRST_NAME FROM collaborator WHERE ID_COLLAB = :ID_COLLAB");
       query.bindValue(":ID_COLLAB", value);
       if (query.exec() && query.next()) {
           // If the value is found, send the name of the person to the Arduino
           QString name = query.value(0).toString();
           QByteArray data = name.toUtf8();
           A.write_to_arduino(data);
       } else {
           // If the value is not found, send "not found" to the Arduino
           QByteArray data = "not found";
           A.write_to_arduino(data);
       }
}
