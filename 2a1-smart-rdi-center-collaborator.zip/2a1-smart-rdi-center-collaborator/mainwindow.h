#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include "collaborator.h"
#include "arduino.h"
#include "ui_mainwindow.h"

#include <QMainWindow>


#define nullptr NULL
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_add_3_clicked();
   // void on_pushButton_delete_clicked();

    void on_add_2_clicked();

   // void on_pushButton_clicked();

   // void on_pushButton_clicked();

   // void on_modify_clicked();

    void on_update_clicked();

   // void on_pushButton_clicked();

    void on_sort_clicked();

   // void on_search_clicked();

    void on_Print_clicked();
  //  void setData(QModelIndex);
    void on_tableView_clicked(const QModelIndex &index);

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();



    void on_sort_2_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

    void on_searchcollab_textChanged(const QString &arg1);

    void on_pushButton_6_clicked();

    void on_pushButton_7_clicked();

private:
    Ui::MainWindow *ui;

   collaborator Etmp;

   QByteArray data; // variable containing the received data

   Arduino A; // temporary object
Arduino B;

private slots:
    void runLoop() {
        QString value = A.read_from_arduino2(); // assuming A is an instance of your Arduino object


        if (value.length()>2) {
            ui->arduinoo->setText(value);
        // Execute the query to check if the value is present in the database
        QSqlQuery query;
        query.prepare("SELECT FIRST_NAME FROM collaborator WHERE Institution = :Institution");
        query.bindValue(":Institution", value);
        if (query.exec() && query.next()) {
            // If the value is found, send the name of the person to the Arduino
            QString name = query.value(0).toString();
            QByteArray data = name.toUtf8();
            A.write_to_arduino(data);
        } else {
            // If the value is not found, send "not found" to the Arduino
            QByteArray data = "not found";
            A.write_to_arduino(data);
        }
    }
}
};

#endif // MAINWINDOW_H

